# Insol Prediction for PCC Cement (Mill CM01)

Predicts the daily **Insol** (insoluble residue, %) of Portland Composite Cement from its chemical
composition (SiO2, Al2O3, Fe2O3, CaO, MgO, SO3, Na2O, K2O, P2O5), residue and fineness (Blaine),
plus lagged values. The whole workflow is time-aware: no random splits, no leakage from test into training.

## Approach

1. **Data prep**: rebuild real dates from the sheet's month/day columns, convert `--` to missing, set
   physically impossible values (CaO < 40, Al2O3 < 1) to missing.
2. **Chronological 80/20 split.** KNN imputation and scaling are fitted on train only.
3. **EDA** on train: distributions, Shapiro-Wilk, correlation (levels and differenced), VIF, seasonality, ACF.
4. **Features**: lags (1, 2, 3, 5, 10 days) of the 8 core oxides.
5. **Model selection** with `TimeSeriesSplit` on train across 9 regressors; the winner is compared with naive baselines on test.
6. **EWMA residual correction**: recent residuals correct the next prediction; span chosen by CV on train.
7. **Improved correction**: tuned Ridge/Lasso/ElasticNet, out-of-fold residuals, shrinkage factor, Wilcoxon + block-bootstrap significance, Ljung-Box.
8. **Experiments**: Insol lags as features, periodic retraining, Huber regression.
9. **Inference**: next-day prediction and per-row prediction from an hourly QC CSV.

In the original run the Lasso + EWMA(7) model reached MAE ~ 0.56 and R2 ~ 0.79 on the test period, and
Huber + EWMA(7) reached MAE ~ 0.55 (not a statistically significant difference). Re-run the notebook to reproduce.

## Repository layout

```
insol_prediction.ipynb   the full pipeline (sections 1 to 13)
requirements.txt
data/                    put the input files here (git-ignored)
outputs/                 figures, predictions, saved model (git-ignored)
```

## Run it

```bash
pip install -r requirements.txt
jupyter notebook insol_prediction.ipynb
```

Input files (not included, git-ignored):

| File | Description |
|------|-------------|
| `data/Kualitas semen 2021-2026.xlsx`, sheet `CM01PCC` | daily lab data: `BULAN`, `Tgl.`, the 11 feature columns, `Insol` |
| `data/QC_hourly.csv` *(optional)* | hourly QC export with `SamplingLocalTime` and the oxide columns |
| `data/data_baru.xlsx` *(optional)* | days after the last date in the main sheet, with actual `Insol` |

Different location? Set `INSOL_DATA_DIR` (and optionally `INSOL_OUTPUT_DIR`) before launching Jupyter.
On Google Colab, uncomment the Drive lines in the configuration cell.

## Important caveats

- EWMA correction needs the previous days' actual Insol at prediction time. If the lab reports with a delay, set `LAB_DELAY_DAYS`.
- Predictions are only as good as the history: if the last known day is more than ~3 days before the target day, lags and correction are stale (the notebook warns you).
- Per-row (hourly) values mean "the daily Insol to expect if the whole day looked like this hour". Compare with the lab value only through their mean.
